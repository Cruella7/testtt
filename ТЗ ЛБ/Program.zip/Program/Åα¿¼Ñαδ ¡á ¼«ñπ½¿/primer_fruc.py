from fractions import Fraction

# Создание дроби с помощью конструктора
a = Fraction(3, 4)
print(a)

# Сложение дробей
b = Fraction(1, 2)
sum_frac = a + b
print(sum_frac)

# Умножение дробей
frac = a * b
print(frac)

# Деление дробей
fracc= a / b
print(fracc)
