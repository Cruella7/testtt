/*Напишите программу для перевода температур по Цельсию в шкалу
Фаренгейта и вывода соответствующей таблицы.*/
#include <stdio.h>

int main() {
    float cels, fahr;
    int low, up, step;

    low = 0;    
    up = 100; 
    step = 10;    

    printf("Таблица температур\n");
    printf("по Цельсию\tпо Фаренгейту\n");

    cels = low;
    while (cels <= up) {
        fahr = (cels * 9 / 5) + 32;
        printf("%8.2f\t%8.2f\n", cels, fahr);
        cels += step;
    }
    return 0;
}
