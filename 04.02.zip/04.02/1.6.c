/*Проверьте, что выражение getchar() != EOF действительно равно 1 или 0..*/
#include <stdio.h>

int main() {
    int a;

    printf("Введите символ: ");
    a = getchar() != EOF;

    printf("Результат: %d\n", a);

    return 0;
}