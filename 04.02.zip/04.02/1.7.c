/*Напишите программу для вывода значения EOF*/
#include <stdio.h>

int main() {
    printf("Значение EOF: %d\n", EOF);
    return 0;
}
