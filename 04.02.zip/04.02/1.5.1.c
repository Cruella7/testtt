/*Напишите программу для перевода температур по Цельсию в шкалу
Фаренгейта и вывода соответствующей таблицы.*/
#include <stdio.h>

int main() {
    int = c;
    c = getchar();
    while (c!= EOF){
        putchar(c);
        c = getchar();
    }
}
