"""
Создать класс Mode1Windo для работы с моделями экранных окон. В качестве полей задаются:
заголовок окна, координаты левого верхнего угла, размер по горизонтали, размер по вертикали,
цвет окна, состояние «видимое/невиди-мое»,
состояние «с рамкой/без рамки». Координаты и размеры указываются в целых числах.
Реализовать операции: передвижение окна по горизонтали.
Арутюнян С.К. 32ИС-21
"""

class Mode1Window:
    def __init__(self, title, x, y, width, height, color, visible=True, with_border=True):
        self.title = title
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.color = color
        self.visible = visible
        self.with_border = with_border

    def horizontal(self, distance):
        self.x += distance

    def visibility(self):
        self.visible = not self.visible

    def border(self):
        self.with_border = not self.with_border

    def display_info(self):
        print(f"Заголовок: {self.title}")
        print(f"Позиция: ({self.x}, {self.y})")
        print(f"Размер: {self.width} x {self.height}")
        print(f"Цвет: {self.color}")
        print(f"Видимость: {'Видимо' if self.visible else 'Скрыто'}")
        print(f"Рамка: {'С рамкой' if self.with_border else 'Без рамки'}")

окно1 = Mode1Window("Моё домашнее задание", 200, 200, 400, 400, "Розовый")
окно1.display_info()

окно1.horizontal(70)
окно1.visibility()
окно1.border()

print("\nПосле операций:")
окно1.display_info()

